import time
from utils.database import db, save_db

# ------------------------------------------------
# OWNER ID (change if needed)
# ------------------------------------------------
OWNER_ID = 1945796348   # Only this user is owner


# ------------------------------------------------
# USER SYSTEM (Auto-create user on first use)
# ------------------------------------------------
def get_user(uid: int):
    """
    Return user object. If not exists → create new user with defaults.
    """
    u = db["users"].setdefault(uid, {
        "plan": "free",
        "premium_until": 0,

        "stats": {
            "forwards_total": 0,
            "forwards_today": 0,
            "gifted_weeks": 0,
        },

        "settings": {
            "notifications": True,
            "preview": True,
            "footer": True,
        },

        # Language (default English)
        "language": "en",
    })

    save_db()
    return u


def is_owner(uid: int):
    """Check if user is owner."""
    return uid == OWNER_ID


# ------------------------------------------------
# PREMIUM SYSTEM
# ------------------------------------------------
def is_premium(uid: int):
    u = get_user(uid)
    plan = u.get("plan", "free")

    if plan == "owner":
        return True

    now = int(time.time())
    exp = u.get("premium_until", 0)

    return exp >= now


def set_user_plan(uid: int, plan: str, hours: int | None):
    u = get_user(uid)

    if plan == "owner":
        u["plan"] = "owner"
        u["premium_until"] = 9999999999
        save_db()
        return

    if hours is None:
        hours = 24  # default

    now = int(time.time())
    exp = now + hours * 3600

    # If stacking (premium already active)
    if u.get("premium_until", 0) > now:
        u["premium_until"] += hours * 3600
    else:
        u["premium_until"] = exp

    u["plan"] = plan
    save_db()


# ------------------------------------------------
# LANGUAGE SYSTEM
# ------------------------------------------------
def set_language(uid: int, lang_code: str):
    u = get_user(uid)
    u["language"] = lang_code
    save_db()


def get_language(uid: int):
    u = get_user(uid)
    return u.get("language", "en")


# ------------------------------------------------
# REFERRAL SYSTEM
# ------------------------------------------------
def ensure_ref(uid: int):
    """
    Ensure referral entry exists.
    """
    r = db["referrals"].setdefault(uid, {
        "invited": [],
        "credits": 0,
    })
    save_db()
    return r


# ------------------------------------------------
# CREDITS SYSTEM
# ------------------------------------------------
def add_credit(uid: int, amount: int):
    r = ensure_ref(uid)
    r["credits"] += amount
    save_db()


def spend_credit(uid: int, amount: int) -> bool:
    r = ensure_ref(uid)
    if r["credits"] < amount:
        return False
    r["credits"] -= amount
    save_db()
    return True


# ------------------------------------------------
# GROUP SYSTEM (Delays, Tiers)
# ------------------------------------------------
def get_group(gid: int):
    g = db["groups"].setdefault(str(gid), {
        "title": "",
        "owner_id": None,
        "tier": "free",
        "paused": False,
        "created": int(time.time())
    })
    save_db()
    return g


def set_group_tier(gid: int, tier: str):
    g = get_group(gid)
    g["tier"] = tier
    save_db()


def get_delay_for_group(gid: int):
    """
    Return delay in seconds based on group tier
    free → 1 sec
    basic → 0.5 sec
    ultra → 0 sec
    owner → 0 sec
    """

    g = get_group(gid)
    tier = g.get("tier", "free")

    if tier == "free":
        return 1
    if tier == "basic":
        return 0.5
    if tier == "ultra":
        return 0
    if tier == "owner":
        return 0

    return 1


# ------------------------------------------------
# STATS SYSTEM
# ------------------------------------------------
def add_forward_stat(uid: int):
    u = get_user(uid)
    stats = u["stats"]

    stats["forwards_total"] = stats.get("forwards_total", 0) + 1
    stats["forwards_today"] = stats.get("forwards_today", 0) + 1

    save_db()


# ------------------------------------------------
# TIME FORMATTER
# ------------------------------------------------
def format_ts(ts: int):
    if not ts:
        return "Never"
    try:
        return time.strftime("%d-%m-%Y %H:%M", time.localtime(ts))
    except:
        return "Unknown"


# ------------------------------------------------
# CLEAN TEXT (for captions)
# ------------------------------------------------
def clean(text: str):
    if not text:
        return ""
    return text.replace("<", "").replace(">", "")
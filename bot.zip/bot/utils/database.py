import json
import os
import time

# Database file path (data.json inside main bot folder)
DB_FILE = os.path.join(os.path.dirname(__file__), "..", "data.json")

# DEFAULT STRUCTURE – yaha hum saare features ka data rakhenge
DEFAULT_DB = {
    "users": {
        # "user_id(str)": {
        #     "plan": "free/basic/ultra/owner/gift/trial",
        #     "premium_until": 0,
        #     "joined_at": 0,
        #     "stats": {
        #         "forwards_total": 0,
        #         "forwards_today": 0,
        #         "keys_redeemed": 0,
        #         "credits": 0,
        #         "referrals": 0,
        #         "gifted_weeks": 0,
        #     },
        #     "settings": {
        #         "notifications": True,
        #         "footer": True,
        #         "preview": True,
        #     },
        #     "ref_code": None,
        # }
    },
    "sources": [
        # { "id": -1001234567890, "tag": "Main Channel", "last_seen": 0 }
    ],
    "groups": {
        # "group_id(str)": {
        #     "title": "My Group",
        #     "owner_id": 123456789,
        #     "tier": "free/basic/ultra/owner",
        #     "paused": False,
        # }
    },
    "keys": {
        # "KEYCODE": {
        #     "plan": "basic",
        #     "hours": 72,
        #     "created_by": 123456789,
        #     "created_at": 0,
        #     "used_by": None,
        #     "used_at": None,
        # }
    },
    "referrals": {
        # "user_id(str)": {
        #     "invited": [123, 456],
        #     "credits": 5
        # }
    },
    "bans": [
        # 123456789
    ],
    "stats": {
        "total_forwards": 0,
        "forwards_today": 0,
        "last_reset": 0,      # day ordinal
        "total_users": 0,
        "total_groups": 0,
        "total_sources": 0,
    },
}


def _ensure_file():
    """Create DB file if not exists."""
    folder = os.path.dirname(DB_FILE)
    if folder and not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)

    if not os.path.exists(DB_FILE):
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_DB, f, ensure_ascii=False, indent=2)


def load_db():
    """Load database from JSON, repair missing keys."""
    _ensure_file()
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}

    # Missing top-level keys fix
    for key, default_val in DEFAULT_DB.items():
        if key not in data:
            # deep copy
            data[key] = json.loads(json.dumps(default_val))

    # Ensure sub-keys for users
    for uid, info in data["users"].items():
        info.setdefault("plan", "free")
        info.setdefault("premium_until", 0)
        info.setdefault("joined_at", int(time.time()))
        info.setdefault("settings", {
            "notifications": True,
            "footer": True,
            "preview": True,
        })
        info.setdefault("stats", {
            "forwards_total": 0,
            "forwards_today": 0,
            "keys_redeemed": 0,
            "credits": 0,
            "referrals": 0,
            "gifted_weeks": 0,
        })
        info.setdefault("ref_code", None)

    return data


def save_db():
    """Save DB object 'db' to JSON file."""
    from utils.database import db  # lazy import to avoid circular
    _ensure_file()
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


# Global DB object used by all modules
db = load_db()
from utils.helpers import get_group

def get_group_delay(gid: int):
    """
    Delay in seconds based on group tier.
    free  = 1 sec
    basic = 0.5 sec
    ultra = 0 sec
    owner = 0 sec
    """
    g = get_group(gid)
    tier = g.get("tier", "free")

    if tier == "free":
        return 1
    if tier == "basic":
        return 0.5
    return 0
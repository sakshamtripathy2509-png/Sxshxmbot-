from telegram.ext import CommandHandler
from utils.database import db, save_db
from utils.helpers import (
    get_user,
    set_user_plan,
    format_ts,
    is_owner,
    ensure_ref,
)

UPI_ID = "Saksham.1412@fam"
OWNER_USERNAME = "SxShxM_Op"

PLAN_NAMES = {
    "free": "Free",
    "trial": "Trial",
    "basic": "Basic",
    "ultra": "Ultra",
    "gift": "Gift",
    "owner": "Owner",
}


async def myprofile(update, context):
    """Show full profile: plan, expiry, stats, credits, referrals etc."""
    user = update.effective_user
    uid = user.id
    u = get_user(uid)
    stats = u.get("stats", {})

    ref = ensure_ref(uid)
    credits = ref.get("credits", 0)
    invited = len(ref.get("invited", []))

    plan = u.get("plan", "free")
    premium_until = u.get("premium_until", 0)

    text = (
        "👤 <b>Your Profile</b>\n\n"
        f"ID: <code>{uid}</code>\n"
        f"Plan: <code>{PLAN_NAMES.get(plan, plan).upper()}</code>\n"
        f"Expires: <code>{format_ts(premium_until)}</code>\n\n"
        f"📨 Forwards total: <code>{stats.get('forwards_total',0)}</code>\n"
        f"Today: <code>{stats.get('forwards_today',0)}</code>\n\n"
        f"🎯 Referrals: <code>{invited}</code>\n"
        f"💳 Credits: <code>{credits}</code>\n"
        f"🎁 Gifted weeks: <code>{stats.get('gifted_weeks',0)}</code>\n"
    )
    await update.message.reply_html(text)


async def premium_info(update, context):
    """Show plan details + payment info."""
    uid = update.effective_user.id
    u = get_user(uid)
    plan = u.get("plan", "free")

    if plan == "owner":
        txt = (
            "👑 <b>OWNER PLAN</b>\n\n"
            "You already have unlimited plan and fastest speed."
        )
        return await update.message.reply_html(txt)

    text = (
        "💎 <b>Premium Plans</b>\n\n"
        "• Trial – 99₹ (7 days)\n"
        "• Basic – 399₹ / month\n"
        "• Ultra – 999₹ / month\n\n"
        "Payment via UPI:\n"
        f"<code>{UPI_ID}</code>\n\n"
        f"Send screenshot to: @{OWNER_USERNAME}\n"
        "Owner will activate your plan manually or via redeem key."
    )
    await update.message.reply_html(text)


async def grant_cmd(update, context):
    """
    Owner: /grant <user_id> <plan> <hours>
    Example: /grant 123456789 basic 720
    """
    user = update.effective_user
    if not is_owner(user.id):
        return await update.message.reply_text("❌ Only owner can grant premium.")

    if len(context.args) < 3:
        return await update.message.reply_text(
            "Usage:\n"
            "/grant <user_id> <plan> <hours>\n\n"
            "Plan: free/trial/basic/ultra/owner/gift"
        )

    try:
        target_id = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("user_id must be integer.")

    plan = context.args[1].lower()
    if plan not in ("free", "trial", "basic", "ultra", "owner", "gift"):
        return await update.message.reply_text(
            "Plan must be one of:\nfree, trial, basic, ultra, owner, gift"
        )

    try:
        hours = int(context.args[2])
    except ValueError:
        return await update.message.reply_text("hours must be integer.")

    if plan == "owner":
        # owner plan unlimited
        set_user_plan(target_id, plan, None)
    else:
        set_user_plan(target_id, plan, hours)

    await update.message.reply_html(
        f"✅ Granted <code>{PLAN_NAMES.get(plan, plan)}</code> to "
        f"<code>{target_id}</code> for <code>{hours}</code> hours."
    )

    # Try notifying user
    try:
        await context.bot.send_message(
            target_id,
            f"🎉 Your plan has been updated to {PLAN_NAMES.get(plan, plan)}!",
        )
    except Exception:
        pass


async def gift_cmd(update, context):
    """
    Owner: /gift <user_id> <hours>
    Plan type will be 'gift'.
    """
    user = update.effective_user
    if not is_owner(user.id):
        return await update.message.reply_text("❌ Only owner can gift premium.")

    if len(context.args) < 2:
        return await update.message.reply_text("Usage:\n/gift <user_id> <hours>")

    try:
        target_id = int(context.args[0])
        hours = int(context.args[1])
    except ValueError:
        return await update.message.reply_text("user_id and hours must be integer.")

    set_user_plan(target_id, "gift", hours)

    # update giver stats (owner)
    owner_u = get_user(user.id)
    st = owner_u.setdefault("stats", {})
    st["gifted_weeks"] = st.get("gifted_weeks", 0) + (hours / (24 * 7))
    save_db()

    await update.message.reply_html(
        f"🎁 Gifted <code>{hours}</code> hours of premium "
        f"to <code>{target_id}</code> (plan=GIFT)."
    )
    try:
        await context.bot.send_message(
            target_id,
            f"🎁 You received a gifted premium for {hours} hours!",
        )
    except Exception:
        pass


def register_premium_handlers(app):
    """Register premium-related commands."""
    app.add_handler(CommandHandler("myprofile", myprofile))
    app.add_handler(CommandHandler("myplan", myprofile))
    app.add_handler(CommandHandler("premium", premium_info))
    app.add_handler(CommandHandler("grant", grant_cmd))
    app.add_handler(CommandHandler("gift", gift_cmd))
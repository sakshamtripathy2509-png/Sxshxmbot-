from telegram.ext import CommandHandler
from utils.database import db, save_db
from utils.helpers import ensure_ref, get_user, set_user_plan, format_ts


async def referral(update, context):
    """Shows referral stats + invite link."""
    user = update.effective_user
    uid = str(user.id)

    r = ensure_ref(user.id)
    invited = r.get("invited", [])
    credits = r.get("credits", 0)

    link = f"https://t.me/{context.bot.username}?start=ref{uid}"

    text = (
        "🎯 <b>Your Referral Panel</b>\n\n"
        f"👥 Invited users: <code>{len(invited)}</code>\n"
        f"💳 Credits: <code>{credits}</code>\n\n"
        f"🔗 Your referral link:\n<code>{link}</code>\n\n"
        "Invite friends and earn rewards!\n"
        "• 1 referral = +1 credit\n"
        "• 5 credits = 7 days premium\n"
    )
    await update.message.reply_html(text)


async def redeemcredits(update, context):
    """User redeems credits for free premium (5 credits = 7 days)."""
    user = update.effective_user
    uid = user.id

    r = ensure_ref(uid)
    credits = r["credits"]

    if credits < 5:
        return await update.message.reply_text(
            f"❌ You need 5 credits for 7 days premium.\n"
            f"Current credits: {credits}"
        )

    r["credits"] -= 5
    save_db()

    # Grant 7 days = 168 hours
    set_user_plan(uid, "trial", 168)

    await update.message.reply_text("🎉 You redeemed 5 credits for 7 days premium!")


async def invitedlist(update, context):
    """See invited users."""
    user = update.effective_user
    r = ensure_ref(user.id)
    invited = r.get("invited", [])

    if not invited:
        return await update.message.reply_text("You haven't invited anyone yet.")

    lines = ["👥 <b>Your Invited Users:</b>"]
    for uid in invited:
        lines.append(f"• <code>{uid}</code>")

    await update.message.reply_html("\n".join(lines))


def register_referral_handlers(app):
    app.add_handler(CommandHandler("referral", referral))
    app.add_handler(CommandHandler("redeemcredits", redeemcredits))
    app.add_handler(CommandHandler("invited", invitedlist))
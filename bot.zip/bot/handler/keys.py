import time
import random
import string
from telegram.ext import CommandHandler
from utils.database import db, save_db
from utils.helpers import is_owner, set_user_plan, get_user, format_ts


def _generate_key(plan: str) -> str:
    """Generate a key like SXSHXM-PLAN-XXXXXXXX."""
    body = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"SXSHXM-{plan.upper()}-{body}"


async def genkey_cmd(update, context):
    """
    Owner: /genkey <plan> <hours>
    Example: /genkey ultra 720
    """
    user = update.effective_user
    if not is_owner(user.id):
        return await update.message.reply_text("❌ Only owner can generate keys.")

    if len(context.args) < 2:
        return await update.message.reply_text(
            "Usage:\n/genkey <plan> <hours>\n\n"
            "Plan: trial/basic/ultra/gift"
        )

    plan = context.args[0].lower()
    if plan not in ("trial", "basic", "ultra", "gift"):
        return await update.message.reply_text(
            "Plan must be one of: trial, basic, ultra, gift"
        )

    try:
        hours = int(context.args[1])
    except ValueError:
        return await update.message.reply_text("hours must be integer.")

    code = _generate_key(plan)
    db["keys"][code] = {
        "plan": plan,
        "hours": hours,
        "created_by": user.id,
        "created_at": int(time.time()),
        "used_by": None,
        "used_at": None,
        "uses": 1,  # single use key
    }
    save_db()

    msg = (
        "🔑 <b>Key generated</b>\n\n"
        f"Code: <code>{code}</code>\n"
        f"Plan: <code>{plan}</code>\n"
        f"Hours: <code>{hours}</code>\n"
    )
    await update.message.reply_html(msg)


async def redeem_cmd(update, context):
    """
    User: /redeem <code>
    """
    if not context.args:
        return await update.message.reply_text("Usage:\n/redeem <code>")

    code = context.args[0].strip().upper()
    info = db["keys"].get(code)

    if not info:
        return await update.message.reply_text("❌ Invalid key.")

    if info.get("uses", 0) <= 0 or info.get("used_by") is not None:
        return await update.message.reply_text("❌ This key has already been used.")

    uid = update.effective_user.id

    plan = info["plan"]
    hours = int(info["hours"])
    # apply
    set_user_plan(uid, plan, hours)

    # update key
    info["used_by"] = uid
    info["used_at"] = int(time.time())
    info["uses"] = 0  # used
    save_db()

    u = get_user(uid)
    text = (
        "✅ <b>Premium Activated!</b>\n\n"
        f"Plan: <code>{u.get('plan','free')}</code>\n"
        f"Expires: <code>{format_ts(u.get('premium_until',0))}</code>\n"
    )
    await update.message.reply_html(text)


async def mykeys_cmd(update, context):
    """Owner: show recent keys."""
    user = update.effective_user
    if not is_owner(user.id):
        return await update.message.reply_text("Owner only.")

    if not db["keys"]:
        return await update.message.reply_text("No keys in database yet.")

    lines = ["🔐 <b>Keys in DB (recent first):</b>"]
    # show last 10
    items = list(db["keys"].items())[-10:]
    for code, info in items[::-1]:
        used = "✅ used" if info.get("used_by") else "❌ unused"
        lines.append(
            f"• <code>{code}</code>\n"
            f"  plan: {info['plan']} hours: {info['hours']} {used}"
        )
    await update.message.reply_html("\n".join(lines))


def register_key_handlers(app):
    """Register key related commands."""
    app.add_handler(CommandHandler("genkey", genkey_cmd))
    app.add_handler(CommandHandler("redeem", redeem_cmd))
    app.add_handler(CommandHandler("mykeys", mykeys_cmd))
from telegram.ext import CommandHandler
from utils.database import db, save_db
from utils.helpers import get_group, set_group_tier, is_owner


async def linkgroup(update, context):
    """Link current group to forwarding system."""
    chat = update.effective_chat
    user = update.effective_user

    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("Use this command *inside a group*.", parse_mode="Markdown")

    g = get_group(chat.id)
    g["title"] = chat.title or "Group"
    g["owner_id"] = user.id
    g.setdefault("tier", "free")
    g.setdefault("paused", False)

    db["stats"]["total_groups"] = len(db["groups"])
    save_db()

    await update.message.reply_text(
        "✅ Group linked!\n"
        f"Title: {g['title']}\n"
        f"Tier: {g['tier']}\n"
        f"Owner: {user.id}"
    )


async def groups_cmd(update, context):
    """List all linked groups."""
    if not db["groups"]:
        return await update.message.reply_text("🎯 No groups linked yet.")

    lines = ["🎯 <b>Linked groups:</b>"]
    for gid, info in db["groups"].items():
        status = "⏸ paused" if info.get("paused") else "▶ active"
        lines.append(
            f"• {info.get('title','?')} (<code>{gid}</code>) "
            f"[tier: <code>{info.get('tier','free')}</code>] {status}"
        )
    await update.message.reply_html("\n".join(lines))


async def setgrouptier(update, context):
    """Set group tier: free/basic/ultra/owner (use in group)."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("Use inside target group.")

    if not context.args:
        return await update.message.reply_text(
            "Usage:\n/setgrouptier free|basic|ultra|owner"
        )

    tier = context.args[0].lower()
    if tier not in ("free", "basic", "ultra", "owner"):
        return await update.message.reply_text("Allowed: free, basic, ultra, owner")

    set_group_tier(chat.id, tier)
    await update.message.reply_text(f"✅ Group tier set to: {tier}")


async def pausegroup(update, context):
    """Pause forwarding to this group."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("Use in group to pause forwarding.")
    g = get_group(chat.id)
    g["paused"] = True
    save_db()
    await update.message.reply_text("⏸ Forwarding paused for this group.")


async def resumegroup(update, context):
    """Resume forwarding to this group."""
    chat = update.effective_chat
    if chat.type not in ("group", "supergroup"):
        return await update.message.reply_text("Use in group to resume forwarding.")
    g = get_group(chat.id)
    g["paused"] = False
    save_db()
    await update.message.reply_text("▶ Forwarding resumed for this group.")


async def delgroup(update, context):
    """Owner can remove a group from DB by ID."""
    uid = update.effective_user.id
    if not is_owner(uid):
        return await update.message.reply_text("Owner only.")

    if not context.args:
        return await update.message.reply_text("Usage: /delgroup <group_id>")

    gid = context.args[0]
    if gid in db["groups"]:
        info = db["groups"].pop(gid)
        db["stats"]["total_groups"] = len(db["groups"])
        save_db()
        await update.message.reply_text(f"Deleted group: {info.get('title','?')} ({gid})")
    else:
        await update.message.reply_text("Group not found in DB.")


def register_group_handlers(app):
    """Register group-related commands."""
    app.add_handler(CommandHandler("linkgroup", linkgroup))
    app.add_handler(CommandHandler("groups", groups_cmd))
    app.add_handler(CommandHandler("setgrouptier", setgrouptier))
    app.add_handler(CommandHandler("pausegroup", pausegroup))
    app.add_handler(CommandHandler("resumegroup", resumegroup))
    app.add_handler(CommandHandler("delgroup", delgroup))
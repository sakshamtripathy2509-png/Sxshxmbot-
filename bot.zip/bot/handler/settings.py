from telegram.ext import CommandHandler
from utils.helpers import get_user
from utils.database import save_db

async def settings_cmd(update, context):
    uid = update.effective_user.id
    user = get_user(uid)

    notif = "ON" if user["settings"]["notifications"] else "OFF"
    preview = "ON" if user["settings"]["preview"] else "OFF"
    footer = "ON" if user["settings"]["footer"] else "OFF"

    text = (
        "⚙️ <b>Your Settings</b>\n\n"
        f"🔔 Notifications: <code>{notif}</code>\n"
        f"🖼 Preview Mode: <code>{preview}</code>\n"
        f"🏷 Footer Tag: <code>{footer}</code>\n\n"
        "Commands:\n"
        "/tognotif - Toggle notifications\n"
        "/togpreview - Toggle preview\n"
        "/togfooter - Toggle footer\n"
        "/language - Change language"
    )
    await update.message.reply_html(text)


async def togglenotif(update, context):
    user = get_user(update.effective_user.id)
    user["settings"]["notifications"] = not user["settings"]["notifications"]
    save_db()
    await update.message.reply_text("🔄 Notifications updated!")


async def togglepreview(update, context):
    user = get_user(update.effective_user.id)
    user["settings"]["preview"] = not user["settings"]["preview"]
    save_db()
    await update.message.reply_text("🔄 Preview updated!")


async def togglefooter(update, context):
    user = get_user(update.effective_user.id)
    user["settings"]["footer"] = not user["settings"]["footer"]
    save_db()
    await update.message.reply_text("🔄 Footer updated!")


def register_settings_handlers(app):
    app.add_handler(CommandHandler("settings", settings_cmd))
    app.add_handler(CommandHandler("tognotif", togglenotif))
    app.add_handler(CommandHandler("togpreview", togglepreview))
    app.add_handler(CommandHandler("togfooter", togglefooter))
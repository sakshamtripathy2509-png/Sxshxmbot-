import asyncio
import logging
import time
from telegram.ext import MessageHandler, filters
from utils.database import db, save_db
from utils.helpers import get_group, get_delay_for_group, get_user

logger = logging.getLogger("forwarding")


async def forward_to_group_with_retry(msg, target_chat_id: int, caption: str | None):
    """
    Forward/copy with up to 3 retries.
    Returns True on success, False on final failure.
    """
    for attempt in range(1, 4):
        try:
            await msg.copy(
                chat_id=target_chat_id,
                caption=caption,
                parse_mode="HTML"
            )
            logger.info("Forwarded to %s (attempt %s)", target_chat_id, attempt)
            return True
        except Exception as e:
            logger.warning("Forward error to %s (attempt %s): %s", target_chat_id, attempt, e)
            await asyncio.sleep(1)
    return False


async def channel_post_handler(update, context):
    """
    Core forwarding logic:
    - Trigger: message from any channel
    - Check if channel is in db['sources']
    - Forward to all linked groups (db['groups'])
    - Respect group pause/tier + owner delay
    - Update stats per user and global
    """
    msg = update.effective_message
    chat = update.effective_chat
    if not msg or not chat or chat.type != "channel":
        return

    src_id = chat.id

    # Check if this channel is a configured source
    src_obj = None
    for s in db["sources"]:
        if s["id"] == src_id:
            src_obj = s
            break

    if not src_obj:
        return  # not a source channel, ignore

    # Update last_seen for this source
    src_obj["last_seen"] = int(time.time())
    save_db()

    tag = src_obj.get("tag", "")

    # Prepare caption with optional tag
    caption = msg.caption_html or msg.text_html or ""
    if tag:
        caption = (caption or "") + f"\n\n📌 Via: {tag}"

    total_groups = len(db["groups"])
    done = 0

    for gid, info in list(db["groups"].items()):
        done += 1
        g = get_group(int(gid))

        if g.get("paused"):
            logger.info("Skipping paused group %s", gid)
            continue

        delay = get_delay_for_group(int(gid))
        if delay > 0:
            await asyncio.sleep(delay)

        # group owner stats
        owner_id = g.get("owner_id")
        owner = get_user(owner_id) if owner_id else None

        ok = await forward_to_group_with_retry(msg, int(gid), caption)
        if not ok:
            logger.warning("Failed to forward to group %s after retries", gid)
            continue

        # global stats
        db["stats"]["total_forwards"] = db["stats"].get("total_forwards", 0) + 1

        # owner stats
        if owner:
            st = owner.setdefault("stats", {})
            st["forwards_total"] = st.get("forwards_total", 0) + 1
            st["forwards_today"] = st.get("forwards_today", 0) + 1

        save_db()

    logger.info("Forward batch finished: %s/%s groups", done, total_groups)


def register_forwarding_handlers(app):
    """
    Register the handler that listens to channel posts
    and forwards them.
    """
    app.add_handler(MessageHandler(filters.ChatType.CHANNEL, channel_post_handler))
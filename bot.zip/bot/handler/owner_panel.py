from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CommandHandler, CallbackQueryHandler
from utils.helpers import is_owner, get_user
from utils.database import db, save_db


# ---------- MAIN /OWNERPANEL COMMAND ----------

async def ownerpanel(update, context):
    uid = update.effective_user.id
    if not is_owner(uid):
        return await update.message.reply_text("❌ Owner only.")

    text = (
        "👑 <b>OWNER CONTROL PANEL</b>\n\n"
        "Choose a section below:"
    )

    kb = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("👥 Users", callback_data="op_users"),
                InlineKeyboardButton("👨‍👩‍👦 Groups", callback_data="op_groups"),
            ],
            [
                InlineKeyboardButton("🔑 Keys & Premium", callback_data="op_keys"),
                InlineKeyboardButton("🎯 Referrals", callback_data="op_referrals"),
            ],
            [
                InlineKeyboardButton("📊 Stats", callback_data="op_stats"),
                InlineKeyboardButton("🛠 System", callback_data="op_system"),
            ],
            [
                InlineKeyboardButton("📢 Broadcast Help", callback_data="op_broadcast"),
            ],
        ]
    )

    await update.message.reply_html(text, reply_markup=kb)


# ---------- INLINE BUTTON HANDLER ----------

async def ownerpanel_cb(update, context):
    query = update.callback_query
    uid = query.from_user.id

    if not is_owner(uid):
        return await query.answer("Not allowed.", show_alert=True)

    data = query.data

    if data == "op_users":
        await show_users_panel(query, context)
    elif data == "op_groups":
        await show_groups_panel(query, context)
    elif data == "op_keys":
        await show_keys_panel(query, context)
    elif data == "op_referrals":
        await show_referrals_panel(query, context)
    elif data == "op_stats":
        await show_stats_panel(query, context)
    elif data == "op_system":
        await show_system_panel(query, context)
    elif data == "op_broadcast":
        await show_broadcast_panel(query, context)
    else:
        await query.answer("Unknown action.")


# ---------- PANELS ----------

async def show_users_panel(query, context):
    users = db["users"]
    total = len(users)

    sample = list(users.keys())[:10]  # top 10 ids

    lines = [
        "👥 <b>Users Panel</b>\n",
        f"Total users: <code>{total}</code>\n",
        "Sample user IDs:",
    ]
    if sample:
        for uid in sample:
            u = users[uid]
            plan = u.get("plan", "free")
            lines.append(f"• <code>{uid}</code> [plan: {plan}]")
    else:
        lines.append("No users yet.")

    lines.append(
        "\nManual commands:\n"
        "/grant & /gift – give premium\n"
        "/redeem – user uses key\n"
    )

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML"
    )


async def show_groups_panel(query, context):
    groups = db["groups"]
    total = len(groups)

    lines = [
        "👨‍👩‍👦 <b>Groups Panel</b>\n",
        f"Total linked groups: <code>{total}</code>\n"
    ]

    count = 0
    for gid, g in groups.items():
        if count >= 10:
            lines.append("… (only showing first 10)")
            break
        tier = g.get("tier", "free")
        title = g.get("title", "?")
        paused = "⏸" if g.get("paused") else "▶"
        lines.append(
            f"• {title} (<code>{gid}</code>) [{tier}] {paused}"
        )
        count += 1

    lines.append(
        "\nManual commands in group:\n"
        "/linkgroup – link group\n"
        "/setgrouptier – set tier\n"
        "/pausegroup /resumegroup\n"
    )

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML"
    )


async def show_keys_panel(query, context):
    keys = db["keys"]
    if not keys:
        text = (
            "🔑 <b>Keys & Premium</b>\n\n"
            "No keys in database.\n\n"
            "Use:\n"
            "/genkey & /mykeys\n"
        )
        return await query.edit_message_text(text, parse_mode="HTML")

    items = list(keys.items())[-10:]  # last 10
    lines = ["🔑 <b>Keys & Premium</b>\n", "Last keys:"]

    for code, info in items[::-1]:
        plan = info.get("plan", "?")
        hours = info.get("hours", 0)
        used_by = info.get("used_by")
        status = f"✅ used by {used_by}" if used_by else "❌ unused"
        lines.append(
            f"• <code>{code}</code>\n"
            f"  plan={plan}, hours={hours}, {status}"
        )

    lines.append(
        "\nCommands:\n"
        "/genkey & /redeem – manage keys\n"
    )

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML"
    )


async def show_referrals_panel(query, context):
    refs = db["referrals"]
    if not refs:
        return await query.edit_message_text(
            "🎯 <b>Referrals Panel</b>\n\nNo referral data yet.",
            parse_mode="HTML",
        )

    # sort by credits (top referrers)
    items = sorted(
        refs.items(),
        key=lambda kv: kv[1].get("credits", 0),
        reverse=True
    )

    lines = ["🎯 <b>Referrals Panel</b>\n", "Top referrers by credits:"]

    top = 0
    for uid, info in items:
        if top >= 10:
            lines.append("… (only showing top 10)")
            break
        credits = info.get("credits", 0)
        invited = len(info.get("invited", []))
        lines.append(
            f"• <code>{uid}</code> – credits: {credits}, invited: {invited}"
        )
        top += 1

    lines.append(
        "\nUser commands:\n"
        "/referral – check their own stats\n"
        "/redeemcredits – convert credits → premium\n"
    )

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode="HTML"
    )


async def show_stats_panel(query, context):
    s = db["stats"]

    text = (
        "📊 <b>Global Stats</b>\n\n"
        f"Total Users: <code>{s.get('total_users',0)}</code>\n"
        f"Total Groups: <code>{s.get('total_groups',0)}</code>\n"
        f"Total Sources: <code>{s.get('total_sources',0)}</code>\n"
        f"Total Forwards: <code>{s.get('total_forwards',0)}</code>\n"
    )
    await query.edit_message_text(text, parse_mode="HTML")


async def show_system_panel(query, context):
    text = (
        "🛠 <b>System Panel</b>\n\n"
        "Here are important owner-level commands:\n\n"
        "Premium & Keys:\n"
        "• /grant <uid> <plan> <hours>\n"
        "• /gift <uid> <hours>\n"
        "• /genkey <plan> <hours>\n"
        "• /mykeys\n\n"
        "Groups:\n"
        "• /delgroup <group_id>\n\n"
        "Referrals & Credits:\n"
        "• /referral, /credits, /giftcredit\n"
    )
    await query.edit_message_text(text, parse_mode="HTML")


async def show_broadcast_panel(query, context):
    text = (
        "📢 <b>Broadcast Help</b>\n\n"
        "To send a message to all users:\n\n"
        "<code>/broadcast Your message here</code>\n\n"
        "Example:\n"
        "<code>/broadcast New update is live! 🎉</code>\n\n"
        "Bot will send this text to all saved users."
    )
    await query.edit_message_text(text, parse_mode="HTML")


# ---------- BROADCAST COMMAND ----------

async def broadcast_cmd(update, context):
    """Owner: /broadcast <message to send all users>"""
    uid = update.effective_user.id
    if not is_owner(uid):
        return await update.message.reply_text("❌ Owner only.")

    if not context.args:
        return await update.message.reply_text(
            "Usage:\n/broadcast <message to send to all users>"
        )

    text = " ".join(context.args)

    count = 0
    for user_id in db["users"].keys():
        try:
            await context.bot.send_message(int(user_id), text)
            count += 1
        except:
            continue

    await update.message.reply_text(f"✅ Broadcast sent to {count} users.")


# ---------- REGISTER ----------

def register_owner_panel_handlers(app):
    app.add_handler(CommandHandler("ownerpanel", ownerpanel))
    app.add_handler(CommandHandler("broadcast", broadcast_cmd))
    app.add_handler(CallbackQueryHandler(ownerpanel_cb, pattern="^op_"))
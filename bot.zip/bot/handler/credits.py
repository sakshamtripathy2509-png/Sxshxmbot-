from telegram.ext import CommandHandler
from utils.helpers import ensure_ref, add_credit, spend_credit
from utils.database import save_db


async def credits(update, context):
    """Show user credit balance."""
    user = update.effective_user
    r = ensure_ref(user.id)
    credits = r.get("credits", 0)
    await update.message.reply_text(f"💳 Your credits: {credits}")


async def giftcredit(update, context):
    """
    /giftcredit <user_id> <amount>
    Send credits to another user.
    """
    user = update.effective_user
    uid = user.id

    if len(context.args) < 2:
        return await update.message.reply_text(
            "Usage:\n/giftcredit <user_id> <amount>"
        )

    try:
        target = int(context.args[0])
        amount = int(context.args[1])
    except ValueError:
        return await update.message.reply_text("User ID and amount must be integers.")

    # Check user has credits
    if not spend_credit(uid, amount):
        return await update.message.reply_text("❌ You don't have enough credits.")

    # Give credits to target
    add_credit(target, amount)

    await update.message.reply_text(
        f"🎁 Sent {amount} credits to {target}!"
    )


def register_credit_handlers(app):
    app.add_handler(CommandHandler("credits", credits))
    app.add_handler(CommandHandler("giftcredit", giftcredit))
import time
from telegram.ext import CommandHandler
from utils.database import db, save_db
from utils.helpers import is_owner, format_ts


async def addsource(update, context):
    """Owner can add a source channel with optional tag."""
    uid = update.effective_user.id
    if not is_owner(uid):
        return await update.message.reply_text("❌ Only owner can add source channels.")

    if not context.args:
        return await update.message.reply_text(
            "Usage:\n"
            "/addsource <channel_id> [tag]\n\n"
            "Example:\n"
            "/addsource -1001234567890 MainChannel"
        )

    raw = context.args[0]
    tag = context.args[1] if len(context.args) > 1 else ""

    try:
        cid = int(raw)
    except ValueError:
        return await update.message.reply_text("❌ Channel id must be an integer (like -1001234567890).")

    # Already exists?
    for s in db["sources"]:
        if s["id"] == cid:
            return await update.message.reply_text("ℹ️ This channel is already in sources.")

    db["sources"].append(
        {
            "id": cid,
            "tag": tag,
            "last_seen": 0,
        }
    )
    db["stats"]["total_sources"] = len(db["sources"])
    save_db()
    await update.message.reply_text(f"✅ Source added:\nID: `{cid}`\nTag: `{tag or 'None'}`", parse_mode="Markdown")


async def remsource(update, context):
    """Remove a source channel."""
    uid = update.effective_user.id
    if not is_owner(uid):
        return await update.message.reply_text("❌ Only owner can remove sources.")
    if not context.args:
        return await update.message.reply_text("Usage: /remsource <channel_id>")

    try:
        cid = int(context.args[0])
    except ValueError:
        return await update.message.reply_text("❌ Channel id must be integer.")

    before = len(db["sources"])
    db["sources"] = [s for s in db["sources"] if s["id"] != cid]
    after = len(db["sources"])
    db["stats"]["total_sources"] = after
    save_db()

    if before == after:
        await update.message.reply_text("⚠️ That source was not found.")
    else:
        await update.message.reply_text(f"✅ Source removed: `{cid}`", parse_mode="Markdown")


async def listsources(update, context):
    """List all source channels."""
    if not db["sources"]:
        return await update.message.reply_text("📡 No source channels configured yet.")

    now = int(time.time())
    lines = ["📡 <b>Source channels:</b>"]
    for s in db["sources"]:
        cid = s["id"]
        tag = s.get("tag", "")
        last = s.get("last_seen", 0)
        if last:
            age = now - last
            inactive = " (inactive)" if age > 7 * 86400 else ""
            last_txt = format_ts(last)
        else:
            inactive = " (never seen yet)"
            last_txt = "N/A"
        lines.append(
            f"• <code>{cid}</code> tag: <code>{tag or '-'}</code>\n"
            f"  last post: <code>{last_txt}</code>{inactive}"
        )

    await update.message.reply_html("\n".join(lines))


def register_source_handlers(app):
    """Register all source-related commands."""
    app.add_handler(CommandHandler("addsource", addsource))
    app.add_handler(CommandHandler("remsource", remsource))
    app.add_handler(CommandHandler("sources", listsources))
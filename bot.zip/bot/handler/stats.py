from telegram.ext import CommandHandler
from utils.database import db


async def stats(update, context):
    s = db["stats"]

    text = (
        "📊 <b>Bot Statistics</b>\n\n"
        f"Total Users: <code>{s.get('total_users',0)}</code>\n"
        f"Total Groups: <code>{s.get('total_groups',0)}</code>\n"
        f"Total Sources: <code>{s.get('total_sources',0)}</code>\n"
        f"Total Forwards: <code>{s.get('total_forwards',0)}</code>\n"
    )

    await update.message.reply_html(text)


def register_stats_handlers(app):
    app.add_handler(CommandHandler("stats", stats))
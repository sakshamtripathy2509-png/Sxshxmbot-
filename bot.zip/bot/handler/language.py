from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CallbackQueryHandler, CommandHandler
from utils.database import db, save_db
from utils.helpers import get_user

# Supported languages
LANGUAGES = {
    "en": "English 🇬🇧",
    "hi": "Hindi 🇮🇳",
}


async def language_cmd(update, context):
    """Show inline button menu to select language."""
    keyboard = [
        [InlineKeyboardButton(name, callback_data=f"lang_{code}")]
        for code, name in LANGUAGES.items()
    ]

    await update.message.reply_text(
        "🌐 <b>Select your language:</b>",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML",
    )


async def language_callback(update, context):
    """Handle language button press."""
    query = update.callback_query
    uid = query.from_user.id
    data = query.data

    if not data.startswith("lang_"):
        return

    # extract language code
    code = data.replace("lang_", "")
    if code not in LANGUAGES:
        return await query.answer("Invalid selection.")

    # update user language
    user = get_user(uid)
    user["language"] = code
    save_db()

    await query.answer("Language updated!", show_alert=False)

    await query.edit_message_text(
        f"🌐 Language set to: <b>{LANGUAGES[code]}</b>",
        parse_mode="HTML",
    )


def register_language_handlers(app):
    """Register all language-related commands."""
    app.add_handler(CommandHandler("language", language_cmd))
    app.add_handler(CallbackQueryHandler(language_callback, pattern="^lang_"))
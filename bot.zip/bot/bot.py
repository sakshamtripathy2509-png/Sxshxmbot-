import asyncio
import logging
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
)

# ===== IMPORT ALL MODULES =====
from handlers.sources import register_source_handlers
from handlers.groups import register_group_handlers
from handlers.premium import register_premium_handlers
from handlers.owner_panel import register_owner_panel_handlers
from handlers.referral import register_referral_handlers
from handlers.credits import register_credit_handlers
from handlers.keys import register_key_handlers
from handlers.forwarding import register_forwarding_handlers
from handlers.stats import register_stats_handlers
from handlers.settings import register_settings_handlers

from utils.logs import setup_logger
from utils.database import db, save_db
from utils.helpers import is_owner, ensure_ref

# ===== SET BOT TOKEN HERE =====
BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"   # <-- Yaha apna token daalna


# ==========================
# START COMMAND (with referrals)
# ==========================
async def start_cmd(update, context):
    user = update.effective_user
    uid = user.id

    # Add to stats
    db["stats"]["total_users"] = len(db["users"])
    save_db()

    # Referral detection
    if context.args:
        arg = context.args[0]
        if arg.startswith("ref"):
            ref_id = arg.replace("ref", "")

            if ref_id.isdigit() and int(ref_id) != uid:
                r = ensure_ref(int(ref_id))

                if uid not in r["invited"]:
                    r["invited"].append(uid)
                    r["credits"] += 1
                    save_db()

                    # Notify referrer
                    try:
                        await context.bot.send_message(
                            int(ref_id),
                            "🎉 Someone joined using your referral link! (+1 credit)"
                        )
                    except:
                        pass

    text = (
        "🤖 <b>MAX AUTO-FORWARD BOT</b>\n\n"
        "I forward posts from source channels to linked groups.\n"
        "Earn free premium using referrals!\n\n"
        "Use /help to see all commands."
    )
    await update.message.reply_html(text)


# ==========================
# HELP COMMAND
# ==========================
async def help_cmd(update, context):
    text = (
        "📚 <b>Help Menu</b>\n\n"
        "Basic:\n"
        "/start - Start bot\n"
        "/help - Command list\n"
        "/myprofile - Your plan & stats\n"
        "/premium - View premium plans\n"
        "/referral - Referral system\n"
        "/redeemcredits - Convert credits → premium\n"
        "/credits - Check your credits\n"
        "/invited - See invited users\n\n"

        "Groups:\n"
        "/linkgroup - Link group\n"
        "/groups - List linked groups\n"
        "/setgrouptier - Set group tier\n"
        "/pausegroup - Pause forwarding\n"
        "/resumegroup - Resume forwarding\n"

        "Sources (owner):\n"
        "/addsource <id> - Add source channel\n"
        "/remsource <id> - Remove source\n"
        "/sources - List all sources\n\n"

        "Keys & Premium:\n"
        "/genkey <plan> <hours> (owner)\n"
        "/redeem <key>\n"
        "/grant <uid> <plan> <hours> (owner)\n"
        "/gift <uid> <hours> (owner)\n"
        "/mykeys - Owner key list\n\n"

        "Admin Panel:\n"
        "/ownerpanel - Owner dashboard\n"
        "/stats - Bot stats\n"
    )

    await update.message.reply_html(text)


# ==========================
# MAIN FUNCTION
# ==========================
async def main():
    setup_logger()
    logger = logging.getLogger("MAXBOT")

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Core commands
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("help", help_cmd))

    # Register all modules
    register_source_handlers(app)
    register_group_handlers(app)
    register_premium_handlers(app)
    register_owner_panel_handlers(app)
    register_referral_handlers(app)
    register_credit_handlers(app)
    register_key_handlers(app)
    register_forwarding_handlers(app)
    register_stats_handlers(app)
    register_settings_handlers(app)

    logger.info("MAXBOT IS RUNNING…")
    await app.run_polling()


if __name__ == "__main__":
    asyncio.run(main())